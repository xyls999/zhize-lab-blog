---
title: Bar 功能
icon: lightbulb
---

## 介绍

我们支持 bar 功能，...

## 详情

- [baz](baz.md)
- ...
