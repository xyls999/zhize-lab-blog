export const redirectMap = {};
