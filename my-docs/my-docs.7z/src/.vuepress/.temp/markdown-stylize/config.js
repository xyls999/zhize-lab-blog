import "E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@mdit+plugin-spoiler@0.22.2_markdown-it@14.1.0/node_modules/@mdit/plugin-spoiler/spoiler.css"


