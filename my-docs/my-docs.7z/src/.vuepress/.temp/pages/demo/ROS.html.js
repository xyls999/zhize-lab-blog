import comp from "D:/vuepress-theme-hope/project_of_zhizelab/my-docs/src/.vuepress/.temp/pages/demo/ROS.html.vue"
const data = JSON.parse("{\"path\":\"/demo/ROS.html\",\"title\":\"ROS培训\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"ROS培训\",\"icon\":\"robot\",\"category\":[\"技术文档\",\"ROS机器人\"],\"tag\":[\"ROS机器人\",\"培训\"],\"description\":\"这里写ROS培训内容（总述） 在写了，在写了\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"ROS培训\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"Mr.Hope\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/demo/ROS.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"智泽实验室\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"ROS培训\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"这里写ROS培训内容（总述） 在写了，在写了\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"培训\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"ROS机器人\"}]]},\"readingTime\":{\"minutes\":0.13,\"words\":40},\"filePathRelative\":\"demo/ROS.md\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
