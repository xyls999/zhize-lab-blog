<template><div><p>你可以通过设置页面的 Frontmatter，在页面禁用功能与布局。</p>
<!-- more -->
<p>本页面就是一个示例，禁用了如下功能:</p>
<ul>
<li>导航栏</li>
<li>侧边栏</li>
<li>路径导航</li>
<li>页面信息</li>
<li>贡献者</li>
<li>编辑此页链接</li>
<li>更新时间</li>
<li>上一篇/下一篇 链接</li>
<li>评论</li>
<li>页脚</li>
<li>返回顶部按钮</li>
</ul>
</div></template>


