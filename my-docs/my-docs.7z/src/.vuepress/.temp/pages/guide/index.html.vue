<template><div><h2 id="功能亮点" tabindex="-1"><a class="header-anchor" href="#功能亮点"><span>功能亮点</span></a></h2>
<h3 id="bar" tabindex="-1"><a class="header-anchor" href="#bar"><span>Bar</span></a></h3>
<ul>
<li><RouteLink to="/guide/bar/baz.html">baz</RouteLink></li>
<li>...</li>
</ul>
<h3 id="foo" tabindex="-1"><a class="header-anchor" href="#foo"><span>Foo</span></a></h3>
<ul>
<li><RouteLink to="/guide/foo/ray.html">ray</RouteLink></li>
<li>...</li>
</ul>
</div></template>


