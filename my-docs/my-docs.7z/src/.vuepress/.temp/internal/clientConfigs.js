import * as clientConfig0 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/git/config.js'
import * as clientConfig1 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/shiki/config.js'
import * as clientConfig2 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/sass-palette/load-hope.js'
import * as clientConfig3 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/markdown-chart/config.js'
import * as clientConfig4 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/markdown-ext/config.js'
import * as clientConfig5 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-h_7a3905d9b79687ebe402ecac424c568e/node_modules/@vuepress/plugin-markdown-hint/lib/client/config.js'
import * as clientConfig6 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/markdown-tab/config.js'
import * as clientConfig7 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/md-enhance/config.js'
import * as clientConfig8 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/markdown-image/client.js'
import * as clientConfig9 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/markdown-stylize/config.js'
import * as clientConfig10 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-theme-data_37a93eb13193c89dc5b2b5f9cf4d3c09/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import * as clientConfig11 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-back-to-to_fc80500282f3536f5ab952c4250cca8b/node_modules/@vuepress/plugin-back-to-top/lib/client/config.js'
import * as clientConfig12 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-copy-code@_a19bd24479b19e2bb3377a38d88c93bf/node_modules/@vuepress/plugin-copy-code/lib/client/config.js'
import * as clientConfig13 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/icon/config.js'
import * as clientConfig14 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-photo-swip_0531e7a2f1d5bacbbfaa139f08af0067/node_modules/@vuepress/plugin-photo-swipe/lib/client/config.js'
import * as clientConfig15 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/components/config.js'
import * as clientConfig16 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-active-hea_eedfe9e9f870a0194020d8be564cb0d6/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import * as clientConfig17 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-catalog@2._3dabc323a3322de9cea0d2d786a96765/node_modules/@vuepress/plugin-catalog/lib/client/config.js'
import * as clientConfig18 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-nprogress@_998e9282b610b2ff00876a16ce7be7d1/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import * as clientConfig19 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-comment@2._87fc69ec6d7617eaaa21cdcc45efabb2/node_modules/@vuepress/plugin-comment/lib/client/config.js'
import * as clientConfig20 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-search@2.0_84d86df2528c4c1f178b27365d6d3ce1/node_modules/@vuepress/plugin-search/lib/client/config.js'
import * as clientConfig21 from 'E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-redirect@2_22ae993ea84e710a9b2ed05e56b34a3a/node_modules/@vuepress/plugin-redirect/lib/client/config.js'
import * as clientConfig22 from 'E:/lab1/zhize-web/my-docs/src/.vuepress/.temp/theme-hope/config.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
  clientConfig12,
  clientConfig13,
  clientConfig14,
  clientConfig15,
  clientConfig16,
  clientConfig17,
  clientConfig18,
  clientConfig19,
  clientConfig20,
  clientConfig21,
  clientConfig22,
].map((m) => m.default).filter(Boolean)
