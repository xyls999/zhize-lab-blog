import { GitContributors } from "E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-git@2.0.0-_1a56bd6cc64dd12044d579adc21d57c6/node_modules/@vuepress/plugin-git/lib/client/components/GitContributors.js";

export default {
  enhance: ({ app }) => {
    app.component("GitContributors", GitContributors);
  },
};
