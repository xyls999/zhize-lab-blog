import "E:/lab1/zhize-web/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-i_15332e2ce3e53316e5329058942137e6/node_modules/@vuepress/plugin-markdown-image/lib/client/styles/figure.css"

